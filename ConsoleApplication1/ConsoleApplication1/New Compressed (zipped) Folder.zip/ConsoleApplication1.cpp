#include <iostream>
#include "clsLogIn.h"



using namespace std ;




int main()
{

    char answer;
    do
    {
        clsLogIn::ShowLogInScreen();
        cout << "\n\nDo you want to log in Again...";
        cin >> answer;
        system("cls");
    } while ('y');
    //system("pause>0");

    return 0;
}