#pragma once

#include <iostream>
#include"clsMainMenuOptions.h"
#include "clsInputValadate.h"
#include "Global.h" 


using namespace std;

class clsLogIn :protected clsShowScreen
{

private:

public:



	static void ShowLogInScreen() {


		_DrawScreenHeader("\t Login Screen");
		bool LogInFaild = false;
		string UserName, PassWord;
		
		do
		{
			if (LogInFaild)
			{
				cout << "\ninValid UserName/Password";
			}
			

			cout << "\nEnter User Name\n";
			UserName = clsInputValidate::ReadString();

			cout << "\nEnter Password\n";
			PassWord= clsInputValidate::ReadString();

			CurrentUser = clsUser::Find(UserName, PassWord);

			LogInFaild = CurrentUser.IsEmpty();



		} while (LogInFaild);

		clsMainMenuOptions::ShowMainMenue();
	}


};

