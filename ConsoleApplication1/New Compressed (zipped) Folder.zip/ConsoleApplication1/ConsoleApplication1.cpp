#include <iostream>
#include "clsLogIn.h"



using namespace std ;




int main()
{

   while(true)
   {
       clsLogIn::ShowLoginScreen();
       return false;
   }
        
       
   
    //system("pause>0");

    return 0;
}